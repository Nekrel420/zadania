let owoce: string[] = ['jabłko', 'arbuz', 'banan', 'gruszka'];
console.log(owoce.length);
console.log(owoce.sort());
owoce.push('amamas');
console.log(owoce);
owoce.shift();
console.log(owoce);
owoce.pop();
console.log(owoce);
owoce.unshift('ananas');
console.log(owoce);
owoce.reverse();
console.log(owoce);

let x: number;
x = 40;
if(x<=0&&x>=15){
    console.log("3zl");
}
else if(x>15&&x<=30){
    console.log(1.50+x*0.20+"zl");
    } else if(x>30&&x<=60){
        console.log(1+0.1*x+"zl");
    }

let num: number[] = [1,2,3,4,5,6,7,8,9];
num.forEach((n)=>{
    if(n%2==0)
        console.log(n+" parzysta");
    else{
        console.log(n+" nieparzysta");
    }
});
