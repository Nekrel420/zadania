class samochody {

    constructor(
        public model: string,
        public marka: string,
        public rocznik: number,
        public wiek: number
    ) {}

    wypisz(): void {
        console.log(`Model: ${this.model}, Marka: ${this.marka}, Rok: ${this.rocznik}, Wiek: ${this.wiek}`);
    }
}

const Auto = new samochody('Civic', 'Honda', 2015, 9);
Auto.wypisz();



class kolorSamochodu extends samochody {
    constructor(
        model: string,
        marka: string,
        rocznik: number,
        wiek: number,
        public kolor: string
    ) {
        super(model, marka, rocznik, wiek);
    }
}

const KolorAuta = new kolorSamochodu('Civic', 'Honda', 2020, 4, "Biały");
KolorAuta.wypisz();
console.log(KolorAuta.kolor);


interface Book {
    title: string;
    author: string;
    year: number;
}

const myBook: Book= {
    title: "Harry Potter",
    author: "J.K. Rowling",
    year: 2000
}

console.log(myBook.title);

interface Person {
    name: string;
    age: number;
    position?: string //zmienna opcjonalna
}

interface Employee extends Person {
    employeeId: number;
}

const employee: Employee = {
    name: "John Doe",
    age: 30,
    employeeId: 123
}

console.log(`${employee.age}, ${employee.employeeId}, ${employee.name}`);