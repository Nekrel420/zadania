let age: number = 12;
let imie: string = "John";
let isTrue: boolean = true;
let n: null = null;
let und: undefined = undefined;
let anything: any = 2.312;
let unsure: unknown = 20;

if(typeof unsure === "number"){
    let num: number = unsure;
}

function greet(name: string): void {
        console.log(`hey ${name}`);
}
greet(imie);
function error(message: string): never{
    throw new Error(message);
}
//error(imie);
let numarray: number[]= [1,2,3,4];
let tuple: [string,number] = ["hello", 42];


enum Color { // Enum: typ wyliczeniowy pozwalający na definiowanie zbioru nazwanych stałych.
    Red,
    Green,
    Blue
}
let c: Color = Color.Green;

let person: {name: string, age: number} = {name: "Jake", age: 30}; //Object: typy obiektów mogą być zdefiniowane przy użyciu typów obiektowych


let value: string|number;
value = "hello";
console.log(value);
value = 2;
console.log(value);

interface version{
    namever: string;
}
interface version2{
    namever2: string;
    }
let app : version & version2 = {namever: "1.0", namever2: "2.0"};
console.log(app);

//typ funkcyjny
let add: (a: number, b: number) => number;
add = (a: number, b: number) => a + b;
console.log(add(1, 1));

let fullname: (first: string,last: string)=>string;
fullname = (first:string,last:string) => first + " " + last;
console.log(fullname("Jan", "Kowalski"));


//zbiór wartości, błąd jeśli nie jest w nim określona wartość
let ocena: 1|2|3|4|5|6;
ocena = 3;

//tablice
let tydzien = ['p','w','ś','c','pi','s','n'];
console.log(tydzien);

let dzien = tydzien[3];
console.log(dzien);

for (let j = 0; j < tydzien.length; j++) {
    console.log(tydzien[j]);
    }

    console.log("Druga petla for");

for (let dzientyg of tydzien){
    console.log(dzientyg);
}

console.log("Trzecia petla for");

tydzien.forEach((dzientyg)=>{
    console.log(dzientyg);
});

//szablony napisowe
console.log(`Dni tygodnia: ${tydzien.join(', ')}`);

let cars: string[] = ['bmw', 'mercedes', 'audi'];


cars.push('toyota'); //dodaje element do tablicy na koncu
console.log(cars.join(' '));

let markausunieta: string = cars.pop()?.toString(); //usuwa ostatni element z tablicy
console.log(cars.join(' '));
console.log(markausunieta);

cars.unshift(markausunieta); //dodaje element na poczatek tablicy
console.log(cars.join(' '));

cars.shift(); //usuwa element z poczatku tablicy
console.log(cars.join(' '));

cars.splice(1,1,'honda'); //usuwa element z indeksem 1 i wstawia 'honda'
console.log(cars.join(' '));

let wybraneauta = cars.slice(1,3); //zwraca tablice z elementami od indeksu
console.log(cars);
console.log(wybraneauta);

let numbers: number[] = [1,2,3,4,5];
let squarednumbers = numbers.map(num=>num*num); //zwraca nowa tablice z elementami podwajonymi
console.log(squarednumbers);

let evennumbers = numbers.filter(num=>num%2===0); //tworzy nowa tablice z elemenetami ktory przeszly test
console.log(evennumbers);

let sum = numbers.reduce((acc,num)=>acc+num,0); //zwraca sume element
console.log(sum);

let foundnumber = numbers.find(num => num > 2);  //zwraca pierwszy element ktory spelnil warunek
console.log(foundnumber);

let foundindex = numbers.findIndex(num => num > 2); // co wyzej, tylko zwraca index elementu
console.log(foundindex);

let haseven = numbers.some(num=>num==2); //zwraca true jesli ktorys element spelnil warunek
console.log(haseven);

let allpositive = numbers.every(num=>num>0); //zwraca true jesli wszystkie elementy spelnil warunek
console.log(allpositive);

cars.sort(); //sortuje elementy
console.log(cars.join(' '));

cars.reverse(); //odwraca kolejnosc
console.log(cars.join(' '));

let hasbmw = cars.includes('bmw'); //zwraca true jesli tablica posiada okreslony element
console.log(hasbmw);

let carsandnumbers = cars.concat(numbers.toString());
console.log(carsandnumbers);

let uczen: [string, string, string] = ['Jan', 'Kowalski', '2B']; //krotki, tuple
console.log(uczen);

