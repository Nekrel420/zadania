function welcome(name: string): void{
    console.log(`Welcome, ${name}!`);
}
welcome("Nick");

function sum(a: number,b: number): number{
    return a + b;
}
console.log(sum(2,2));

//deklaracja funkcji za pomoca wyrazenia
const sum2 = function(a:number,b:number): number{
    return a + b;
}
console.log(sum2(2,4));

function sum3(a: number, b: number = 10): number { // wartosc domyslna dla parametru
    return a + b;
    }
console.log(sum3(2));

function greet2(name: string, age?: number): string{ //parametr opcjonalny
    return `Welcome ${name}, ${age}`;
}
console.log(greet2('jan'));
console.log(greet2('jan',20));

function sum4(...numbers: number[]): number{ //parametr rozpakowywany, dowolna liczba elementow
    return numbers.reduce((a, b) => a + b, 0);
}
console.log(sum4(1,2,3,4,5));

let add = function (x: number, y: number): number { //funkcja anonimowa
    return x + y;
};

let result = add(2,1);
console.log(result);

function powitanie(imie: string): string{
    return `Cześć ${imie}`;
}

const imiona: string[] = ['jan','pawel'];
console.log(imiona.map(powitanie)); //map zwraca kazdy element z tablicy

console.log(imiona.map((imie: string)=> `Cześć ${imie}`)); //funkcja strzalkowa

function describe(value: string): string; //przeciazona funkcja
function describe(value: number): string;
function describe(value: any): string{
    if  (typeof value === 'string'){
        return `String: ${value}`
        }
        else if (typeof value === 'number'){
            return `Number: ${value}`
            }
            return "Unknown type";
            }
console.log(describe("hello"));
console.log(describe(123));

function polacz(separator: string, ...values: string[]): string;
function polacz(separator: string, ...values: number[]): string;

function polacz(separator: string, ...values: (string|number)[]): string{
    return values.join(separator);
}
console.log(polacz(',','a','b','c'));


//zasiegi zmiennych
let pi = 3.14; //globalna zmienna

function pole_kola():void{
    let r = 10; //lokalna
    console.log(pi ** 2);
}
pole_kola();

function getstatus(success: boolean): {success: boolean} | {error: string}{
    if (success){
        return {success: true};
        }
        else{
            return {error: 'Błąd'};
            }
}
const resultx = getstatus(false);
if ('error' in resultx){
    console.log(resultx.error);
    }else{
    console.log(resultx.success);
}
