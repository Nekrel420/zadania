class Student {

    imie: string;
    nazwisko: string;
    wiek: number;
    kontakt: string[];


    constructor (imie:string, nazwisko:string, wiek:number, kontakt:string[]) {

        this.imie = imie;
        this.nazwisko = nazwisko;
        this.wiek = wiek;
        this.kontakt = kontakt;
    }
}

const Nowak = new Student("Adam", "Nowak", 22, ["123456789", "adam.nowak@gmail.com"]);
console.log(`Imię i nazwisko studenta: ${Nowak.imie} ${Nowak.nazwisko}\nDane kontaktowe: tel. ${Nowak.kontakt[0]}, email: ${Nowak.kontakt[1]}`);


//szybszy zapis za pomoca public
class Student2 {

    constructor (
        public imie: string,
        public nazwisko:string,
        public wiek: number,
        public kontakt:string[]
    ) {}

    show(){
        console.log(`Imię i nazwisko studenta: ${this.imie} ${this.nazwisko}\nDane kontaktowe: tel. ${this.kontakt[0]}, email: ${this.kontakt[1]}`);
    }
}

const Nowak2 = new Student2("Adam", "Nowak", 22, ["123456789", "adam.nowak@gmail.com"]);
Nowak2.show();

// dziedziczenie
class Person {

    constructor(
        public imie: string,
        public nazwisko: string,
        public wiek: number,
    ) {}

    showDetails(): void {
        console.log(`Imię i nazwisko: ${this.imie} ${this.nazwisko}, Wiek: ${this.wiek}`);
    }
}

class Nauczyciel extends Person {

    constructor(
        imie: string,
        nazwisko: string,
        wiek: number,
        public staz: number
    ){
        super(imie, nazwisko, wiek); //pozwala na dziedziczenie z klasy person dzieki super
    }

    showDetails(): void {
        super.showDetails();
        console.log(`Staż: ${this.staz}`);
    }
}

const Nauczyciel1 = new Nauczyciel("Jan", "Kowalski", 41, 10);
Nauczyciel1.showDetails();

//nadpisywanie metod 
class Person2 extends Person {

    constructor(
        imie: string,
        nazwisko: string,
        wiek: number
        ) {
            super(imie,nazwisko,wiek);
        }

        showDetails(): void { //nadpisanie metody showDetails
            console.log(`${this.wiek}, ${this.imie}, ${this.nazwisko}`); 
        }
}

const osoba = new Person("Jan", "Kowalski", 41);
const osoba2 = new Person2("Jan", "Kowalski", 41);
osoba.showDetails();
osoba2.showDetails();


//klasy abstrakcyjne
abstract class Auto {

    constructor(
        public marka: string,
        public model: string,
        public rokProdukcji: number
        ) {}

        abstract showDetails(): void; // jest to klasa abstrakcyjna ktora musi byc zaimplementowana w klasach dziedziczacych
}

class Samochod extends Auto {

    constructor(
        marka: string,
        model: string,
        rokProdukcji: number,
        public pojemnosc: number
    ) {
        super(marka, model, rokProdukcji);
    }

    showDetails(): void {
        console.log(`${this.marka}, ${this.model}, ${this.rokProdukcji}, ${this.pojemnosc}`);
    }
}

const Samochod1 = new Samochod("Toyota", "Corolla", 2015, 1.6);
Samochod1.showDetails();

