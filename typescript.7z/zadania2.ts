function bezwzlgedna(liczba: number): number {
    return liczba>0?liczba:liczba*-1;
}
console.log(bezwzlgedna(2));
console.log(bezwzlgedna(-4));

function bmi(wzrost:number, waga: number): string{
    let wynik = waga/(wzrost*wzrost);
    if(wynik<18.5){
        return wynik+" Za mało!";
        }else if(wynik>18.5&&wynik<25){
            return wynik+" Ok!";
        }
        else
        return wynik+" Za dużo!";
}
console.log(bmi(1.70,50));
console.log(bmi(1.70,70));
console.log(bmi(1.89,92));

let tablica: number[] =  [2, 4, 7, 11, 14, 19, 21, 100];
console.log(tablica.filter((liczba)=> liczba%2==0));
console.log(tablica.filter((liczba)=> liczba%2!=0));

const tablica2: number[] = [1, 2, 3, 4, 5, 6];
console.log(tablica2.map((liczba: number)=>liczba*liczba));

let liczbaPI=3.14;
function stozek(): string{
    let r= 10;
    let h = 5;
    let l = 6;
    return `${h}`+" pb "+`${liczbaPI*r*l}`+" pc "+`${liczbaPI*r*(r+l)}`;
}
console.log(stozek());