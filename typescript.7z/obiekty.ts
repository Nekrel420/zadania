const person: {imie: string; nazwisko: string; isActive: boolean} = {
    imie : "alice",
    nazwisko : "berg",
    isActive : true
};

//Możemy tworzyć typy obiektów za pomocą literali typów, co pozwala na dokładniejsze określenie struktury
//obiektów. Tutaj Person to typ, który definiuje strukturę obiektów, a person2 to zmienna tego typu.

type osoba = {
    name: string,
    age: number,
    isActive: boolean
};

const person2: osoba = {
    name: "John",
    age: 30,
    isActive: true
};

//Interfejsy są bardziej rozbudowaną i elastyczną formą definiowania struktur obiektów. Interfejsy mogą być
//rozszerzane i implementowane, co umożliwia tworzenie bardziej złożonych hierarchii typów.

interface pracownik {
    imie: string;
    nazwisko: string;
    idPracownika: number;
}

const person3: pracownik = {
    imie: "Jan",
    nazwisko: "Kowalski",
    idPracownika: 4312
};

interface pozycja extends pracownik {
    pozycja: string;
}

const person4: pozycja = {
    imie: "Joe",
    nazwisko: "Dick",
    idPracownika: 2133,
    pozycja: "Kasjer"
};

let prostokat = {
    dl: 15,
    szr: 20,
    pole: function() {return this.dl*this.szr} //funkcja this pozwala sie odwolac do wlasciwosci obiektu
}
console.log(prostokat.pole());


//odwoluwanie sie wewnatrz obiektu do funkcji

function pokaz(this: {proc: string, ram: string}): void {
    console.log(`procesor: ${this.proc},\n ilosc pamieci ram: ${this.ram}`);
}

const zestaw1 = {
    proc: "intel 1",
    ram: "12kb",
    wyswietl: pokaz
}
zestaw1.wyswietl();

const zestaw2 = {
    proc: "intel core i3-13200",
    ram: "2gb",
    wyswietl: pokaz
}
//bind tworzy nową funkcję, której this jest ustawione na wartość przekazaną jako argument bind
zestaw2.wyswietl = pokaz.bind(zestaw2); //z jakiegos powodu nie dziala xd


//tablice
type computer = {
    processor: string;
    ram: string;
};
const computers: computer[] =[
    {
        processor: "Intel Core i7-11700K",
        ram: "12gb"
    },
    {
        processor: "Intel Core i7-11700K",
        ram: "16gb"
    },
    {
        processor: "Intel Core i7-11700K",
        ram: "32gb"
    },
]

function showcumputers(computers: computer[]): void{
    computers.forEach(computer=>{
        console.log(`${computer.processor}\n${computer.ram}`);
    })
}
showcumputers(computers);


// wyodrebnianie elementow
const teacher = {
    name: "Janusz",
    surname: "Laska",
    age: 30
};
const {surname,age} = teacher;
console.log(surname);
console.log(age);


//opcjonalne zmienne wew obiektu

type contact = {
    name: string;
    email: string;
    phone?: string; //opcjonalne
}
const con1: contact = {
    name: "Janusz",
    email: "janusz.laska@wp.pl",
    phone: "123456789"
}
const con2: contact = {
    name: "Janusz",
    email: "janusz.laska@wp.pl",
}
console.log(con1);
console.log(con2);

//przeciazanie obiektow

type calculation = {
    calculate(value: number): number;
    calculate(value: number, value2:number ): number;
}

const math1: calculation = {
    calculate(value1: number, value2?: number): number{
        if(value2===undefined){
            return value1*value1;
        }
        return value1+value2;
    }
};
console.log(math1.calculate(4));
console.log(math1.calculate(4,2));
