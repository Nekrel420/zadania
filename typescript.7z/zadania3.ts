interface osoba {
    imie: string;
    nazwisko: string;
}
interface adres extends osoba {
    adres: string;
}

const mieszkaniec: adres = {
    imie: "Jan",
    nazwisko: "Kowalski",
    adres: "Chojnice 1"
};


 
const os: osoba[] = [
    {
        imie:"jan",
        nazwisko:"kowalski"
    },
    {
        imie:"janusz",
        nazwisko:"kowal" 
    },
    {
        imie:"janina",
        nazwisko:"zul"
    }
]
function kobieta(os: osoba[]): void{
    os.forEach(element => {
        if(element.imie.substring(element.imie.length - 1)==="a"){
            console.log(element.imie);
        }
    });
}
kobieta(os);

type pracownik = {
    imie: string,
    id: number
};

const pracownicy: pracownik[]=[
    {
        imie: "joe",
        id: 1
    },
    {
        imie: "jamal",
        id: 2
    },
]
const pracownicy2: pracownik[]=[
    {
        imie: "joe",
        id: 1
    },
    {
        imie: "jeremiasz",
        id: 3
    },
    {
        imie: "jeremiasz",
        id: 3
    },
    {
        imie: "jeremiasz",
        id: 3
    },
    {
        imie: "jeremiasz",
        id: 3
    },
    {
        imie: "joe",
        id: 1
    },
    {
        imie: "jamal",
        id: 2
    },
]


function polacz(pracownicy: pracownik[], pracownicy2: pracownik[]): pracownik[]{
    
    const wszyscypracownicy: pracownik[] = [...pracownicy,...pracownicy2];//tworzymy kopie tablicy polaczonej
    const unikatowipracownicy: pracownik[]=[]; //pusta tabica
    const ids = new Set<number>(); //pusta kolekcja 

    for(const pracownik of wszyscypracownicy){ //wybieramy pracownika
        if(!ids.has(pracownik.id)){ // jesli kolekcja nie zawiera id pracownika
            ids.add(pracownik.id); //dodajemy id tego pracownika do kolekcji
            unikatowipracownicy.push(pracownik);//dodajemy pracownika do tablicy unikatowych pracownikow
        }
    }
        return unikatowipracownicy;
}
console.log(polacz(pracownicy,pracownicy2));


//grupowanie tablic wedle id
function group(pracownicy: pracownik[], pracownicy2:pracownik[]):pracownik[]{
    const wszyscypracownicy:pracownik[]=[...pracownicy, ...pracownicy2];
    const zgrupowane:pracownik[]=[];
    const ids = new Set<number>();

    while(wszyscypracownicy.length!=zgrupowane.length){
        for(let i = 0;i<wszyscypracownicy.length;i++){
            let id = wszyscypracownicy[i].id;
            if(!ids.has(id)){
                for(let j = 0;j<wszyscypracownicy.length;j++){
                    if(wszyscypracownicy[j].id==id){
                        zgrupowane.push(wszyscypracownicy[j]);
                    }
                }
            }
            ids.add(id);
        }

    }
    return zgrupowane;
}
console.log(group(pracownicy,pracownicy2));

//sprawdzanie czy tablica spelnia warunek
function sprawdz(pracownicy: pracownik[]): boolean{
    let ids: boolean;
    pracownicy.forEach(pracownik=>{
        pracownik.id==1 ? ids = true: ids = false;
    });
    return ids;
}
console.log(sprawdz(pracownicy));